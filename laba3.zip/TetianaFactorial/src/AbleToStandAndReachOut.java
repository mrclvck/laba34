public interface AbleToStandAndReachOut {
    default void StandAndReachOut(String placeOne, String placeTwo) {}
}
