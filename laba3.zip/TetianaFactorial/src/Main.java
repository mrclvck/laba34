public class Main {
    public static void main(String[] args) {
        Wendy wendy = new Wendy("Венди");
        wendy.wentTo("к кладовке");
        wendy.pushedBack("засов");
        wendy.comeIn("в кладовку");
        wendy.take("томатный суп");
        wendy.lockedUp("дверь");
        wendy.worried();
        wendy.openedJar();
        wendy.putInPot();
        wendy.wentToFridge();
        wendy.tookMilk();
        wendy.tookEggs();
        wendy.tookCheese();
        wendy.calmedDown();
        wendy.meltedButter();
        wendy.addMilk();
        wendy.pouredEggs();
        wendy.turnedAround();
        wendy.calmedDown();
        wendy.heldKnife("нож");
        wendy.sawNoOne("никто");
        wendy.thought(" Возьми себя в руки,девочка ");
        wendy.rubbedCheese();
        wendy.throwUpOmelette("омлет");
        wendy.putPot();
        wendy.putDownDishes("2 глубокие тарелки");
        wendy.putDownDishes("2 мелкие тарелки");
        wendy.putDownDishes("солонку");
        wendy.putDownDishes("перечницу");
        wendy.relocateOmelette("омлет");
        wendy.coveredOmelette("омлет");
        wendy.thought("Назад той же дорогой. Выключить свет. Пройти через контору, воротца. Взять 200 долларов");
        wendy.wentTo("дверце в вестибюле ");
        wendy.stopped("вестибюле");
        wendy.putDownTray();
        wendy.sixSense();


    }

}